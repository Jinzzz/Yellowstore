$(function(e) {
	 $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'excel','pdf', 
        ]
    } );

} );
$(function(e) {
	$('#example5').DataTable();
} );
