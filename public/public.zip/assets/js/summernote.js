$(function(e) {
	  $('#summernote').summernote({
		placeholder: 'Hello bootstrap 4',
		tabsize: 3,
		height: 300
	  });
	});